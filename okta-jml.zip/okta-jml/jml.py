#!/usr/bin/env python3
"""
jml.py - Joiner / Mover / Leaver automation for Okta, driven by an HR CSV feed.

  Joiner : employee is ACTIVE in the feed and has no Okta user  -> create + activate
  Mover  : employee is ACTIVE in the feed and name/department/title/manager changed
           -> partial profile update. `department` drives Okta group rules, so
              role-based access follows the profile change automatically.
  Leaver : employee is TERMINATED in the feed (suspend-then-deprovision):
             Okta ACTIVE                 -> suspend + revoke sessions/tokens   (stage 1)
             Okta SUSPENDED >= N days    -> deactivate (deprovisions apps)     (stage 2)
             Okta DEPROVISIONED >= M days-> delete permanently (optional)      (stage 3)
           Users that were never ACTIVE (STAGED/PROVISIONED) have nothing to
           suspend, so they are deactivated immediately.

Stateless: the leaver clock is Okta's own `statusChanged` timestamp, so no local
state file is needed and re-running the script is safe (idempotent).

Live mode env vars:  OKTA_ORG_URL (https://dev-123456.okta.com)   OKTA_API_TOKEN
Mock mode (--mock) runs the identical logic against a local JSON "tenant" so the
whole lifecycle, including the grace period, can be tested with no Okta org.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import secrets
import string
import sys
import time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

REQUIRED_COLS = ["employee_id", "first_name", "last_name", "email",
                 "department", "title", "manager_email", "status"]
# Okta profile attribute -> CSV column. These are the attributes a Mover may change.
MOVER_ATTRS = {"firstName": "first_name", "lastName": "last_name",
               "department": "department", "title": "title", "manager": "manager_email"}
LIVE = {"STAGED", "PROVISIONED", "ACTIVE", "PASSWORD_EXPIRED", "RECOVERY", "LOCKED_OUT"}
ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
EMAIL_RE = re.compile(r"^[^@\s\"'\\]+@[^@\s\"'\\]+\.[^@\s\"'\\]+$")


class OktaError(Exception):
    def __init__(self, status: int, body: str):
        super().__init__(f"HTTP {status}: {body[:300]}")
        self.status = status


def parse_ts(s: str) -> datetime:
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")


def new_password() -> str:
    """Random, never logged. Lab use only (--active-on-create)."""
    symbols = "!@#%^*-_"
    alphabet = string.ascii_letters + string.digits + symbols
    while True:
        p = "".join(secrets.choice(alphabet) for _ in range(24))
        if (any(c.islower() for c in p) and any(c.isupper() for c in p)
                and any(c.isdigit() for c in p) and any(c in symbols for c in p)):
            return p


# --------------------------------------------------------------------------- #
# Okta clients (live + mock share the same interface)
# --------------------------------------------------------------------------- #
class OktaClient:
    def __init__(self, org_url: str, token: str):
        import requests  # imported lazily so --mock works without it
        self.base = org_url.rstrip("/") + "/api/v1"
        self.s = requests.Session()
        self.s.headers.update({"Authorization": f"SSWS {token}", "Accept": "application/json",
                               "Content-Type": "application/json"})

    def _req(self, method: str, path: str, **kw):
        for _ in range(6):
            r = self.s.request(method, self.base + path, timeout=30, **kw)
            if r.status_code == 429:  # honour Okta rate limiting
                reset = float(r.headers.get("X-Rate-Limit-Reset", time.time() + 2))
                time.sleep(max(1.0, reset - time.time()) + 1)
                continue
            if r.status_code >= 400:
                raise OktaError(r.status_code, r.text)
            return r.json() if r.text else {}
        raise OktaError(429, "rate-limit retries exhausted")

    def find_user(self, employee_id: str, login: str):
        # Search is eventually consistent; fall back to the strongly-consistent
        # login filter so a just-created user is never created twice.
        res = self._req("GET", "/users", params={"search": f'profile.employeeNumber eq "{employee_id}"'})
        if not res:
            res = self._req("GET", "/users", params={"filter": f'profile.login eq "{login}"'})
        return res[0] if res else None

    def create_user(self, profile: dict, password: str | None = None) -> dict:
        body: dict = {"profile": profile}
        if password:
            body["credentials"] = {"password": {"value": password}}
        user = self._req("POST", "/users", params={"activate": "true" if password else "false"}, json=body)
        if not password:  # STAGED -> PROVISIONED, no email sent
            self._req("POST", f"/users/{user['id']}/lifecycle/activate", params={"sendEmail": "false"})
        return self._req("GET", f"/users/{user['id']}")

    def update_profile(self, uid: str, profile: dict):
        return self._req("POST", f"/users/{uid}", json={"profile": profile})  # partial update

    def suspend(self, uid: str):
        return self._req("POST", f"/users/{uid}/lifecycle/suspend")

    def clear_sessions(self, uid: str):
        return self._req("DELETE", f"/users/{uid}/sessions", params={"oauthTokens": "true"})

    def deactivate(self, uid: str):
        return self._req("POST", f"/users/{uid}/lifecycle/deactivate", params={"sendEmail": "false"})

    def delete(self, uid: str):
        return self._req("DELETE", f"/users/{uid}", params={"sendEmail": "false"})


class MockOkta:
    """Tiny in-memory/JSON tenant that enforces the same lifecycle rules as Okta."""

    def __init__(self, path: str, now: datetime):
        self.path, self.now = Path(path), now
        self.db = json.loads(self.path.read_text()) if self.path.exists() else {"seq": 0, "users": {}}

    def _save(self):
        self.path.write_text(json.dumps(self.db, indent=2))

    def _set(self, u, status):
        u["status"], u["statusChanged"] = status, iso(self.now)
        self._save()

    def _get(self, uid):
        if uid not in self.db["users"]:
            raise OktaError(404, "Not found: Resource not found")
        return self.db["users"][uid]

    def find_user(self, employee_id, login):
        for u in self.db["users"].values():
            if u["profile"].get("employeeNumber") == employee_id or u["profile"]["login"] == login:
                return json.loads(json.dumps(u))
        return None

    def create_user(self, profile, password=None):
        self.db["seq"] += 1
        uid = f"mock{self.db['seq']:04d}"
        u = {"id": uid, "profile": dict(profile), "created": iso(self.now)}
        self.db["users"][uid] = u
        self._set(u, "ACTIVE" if password else "PROVISIONED")
        return json.loads(json.dumps(u))

    def update_profile(self, uid, profile):
        u = self._get(uid)
        u["profile"].update({k: v for k, v in profile.items()})
        self._save()

    def suspend(self, uid):
        u = self._get(uid)
        if u["status"] != "ACTIVE":
            raise OktaError(400, "Cannot suspend a user that is not ACTIVE")
        self._set(u, "SUSPENDED")

    def clear_sessions(self, uid):
        self._get(uid)

    def deactivate(self, uid):
        u = self._get(uid)
        if u["status"] == "DEPROVISIONED":
            raise OktaError(400, "User already deactivated")
        self._set(u, "DEPROVISIONED")

    def delete(self, uid):
        u = self._get(uid)
        if u["status"] != "DEPROVISIONED":
            raise OktaError(400, "User must be deactivated before delete")
        del self.db["users"][uid]
        self._save()


# --------------------------------------------------------------------------- #
# Feed handling + planning
# --------------------------------------------------------------------------- #
def load_feed(path: str) -> list[dict]:
    with open(path, newline="", encoding="utf-8-sig") as f:
        rd = csv.DictReader(f)
        missing = [c for c in REQUIRED_COLS if c not in (rd.fieldnames or [])]
        if missing:
            sys.exit(f"CSV is missing required columns: {', '.join(missing)}")
        rows, seen = [], set()
        for n, raw in enumerate(rd, start=2):
            row = {k: (v or "").strip() for k, v in raw.items() if k}
            if not ID_RE.match(row["employee_id"]):
                sys.exit(f"line {n}: invalid employee_id {row['employee_id']!r}")
            if row["employee_id"] in seen:
                sys.exit(f"line {n}: duplicate employee_id {row['employee_id']}")
            if not EMAIL_RE.match(row["email"]):
                sys.exit(f"line {n}: invalid email {row['email']!r}")
            if row["status"].lower() not in ("active", "terminated"):
                sys.exit(f"line {n}: status must be active|terminated, got {row['status']!r}")
            seen.add(row["employee_id"])
            rows.append(row)
    return rows


def to_profile(row: dict) -> dict:
    p = {"employeeNumber": row["employee_id"], "login": row["email"].lower(), "email": row["email"].lower()}
    for okta_attr, col in MOVER_ATTRS.items():
        p[okta_attr] = row[col]
    return p


def item(action, row, detail, run=None):
    return {"action": action, "employee_id": row["employee_id"], "login": row["email"].lower(),
            "detail": detail, "run": run}


def build_plan(rows, client, a, now: datetime) -> list[dict]:
    plan, today = [], now.date()
    for row in rows:
        login, active = row["email"].lower(), row["status"].lower() == "active"
        user = client.find_user(row["employee_id"], login)

        if user is None:
            if active:
                prof = to_profile(row)
                pw = new_password() if a.active_on_create else None
                plan.append(item("JOINER_CREATE", row,
                                 f"create + activate (dept={row['department']!r}, title={row['title']!r})",
                                 lambda p=prof, pw=pw: client.create_user(p, pw)))
            continue  # terminated and never provisioned: nothing to do

        uid, st = user["id"], user["status"]

        if active:
            if st in ("DEPROVISIONED", "SUSPENDED"):
                plan.append(item("REVIEW", row, f"HR says active but Okta status is {st} (rehire/leave?) - manual review"))
                continue
            cur, diff = user["profile"], {}
            for okta_attr, col in MOVER_ATTRS.items():
                if (cur.get(okta_attr) or "") != row[col]:
                    diff[okta_attr] = row[col] or None
            if diff:
                changes = ", ".join(f"{k}: {cur.get(k)!r} -> {v!r}" for k, v in diff.items())
                plan.append(item("MOVER_UPDATE", row, changes, lambda u=uid, d=diff: client.update_profile(u, d)))
            continue

        # ---- leaver ----
        td = row.get("termination_date", "")
        if td and date.fromisoformat(td) > today:
            plan.append(item("SKIP", row, f"termination scheduled for {td}"))
            continue
        age = (now - parse_ts(user["statusChanged"])).days
        if st == "ACTIVE":
            def stage1(u=uid):
                client.suspend(u)
                client.clear_sessions(u)
            plan.append(item("LEAVER_SUSPEND", row, "stage 1: suspend + revoke sessions/tokens", stage1))
        elif st in LIVE:
            plan.append(item("LEAVER_DEACTIVATE", row, f"{st}: never active, nothing to suspend -> deactivate now",
                             lambda u=uid: client.deactivate(u)))
        elif st == "SUSPENDED":
            if age >= a.grace_days:
                plan.append(item("LEAVER_DEACTIVATE", row, f"stage 2: suspended {age}d (grace {a.grace_days}d) -> deactivate",
                                 lambda u=uid: client.deactivate(u)))
            else:
                plan.append(item("WAIT", row, f"suspended {age}d, grace period is {a.grace_days}d"))
        elif st == "DEPROVISIONED" and a.delete_after_days is not None and age >= a.delete_after_days:
            plan.append(item("LEAVER_DELETE", row, f"stage 3: deprovisioned {age}d -> delete permanently",
                             lambda u=uid: client.delete(u)))
    return plan


def execute(plan, a, now) -> int:
    errors = 0
    audit = open(a.audit_log, "a", encoding="utf-8")
    for p in plan:
        result, err = "info", None
        if p["run"] is not None:
            if a.dry_run:
                result = "dry-run"
            else:
                try:
                    p["run"]()
                    result = "ok"
                except OktaError as e:
                    result, err, errors = "error", str(e), errors + 1
        print(f"[{result.upper():7}] {p['action']:<18} {p['employee_id']:<6} {p['login']:<40} {p['detail']}"
              + (f"  !! {err}" if err else ""))
        audit.write(json.dumps({"ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                                "as_of": now.isoformat(timespec="seconds"), "mode": "mock" if a.mock else "live",
                                "dry_run": a.dry_run, "action": p["action"], "employee_id": p["employee_id"],
                                "login": p["login"], "detail": p["detail"], "result": result, "error": err}) + "\n")
    audit.close()
    return errors


def main() -> int:
    ap = argparse.ArgumentParser(description="Okta JML automation from an HR CSV feed")
    ap.add_argument("--csv", required=True, help="HR feed CSV")
    ap.add_argument("--dry-run", action="store_true", help="show the plan, change nothing")
    ap.add_argument("--grace-days", type=int, default=7, help="days SUSPENDED before deactivation (default 7)")
    ap.add_argument("--delete-after-days", type=int, default=None, help="delete DEPROVISIONED users after N days (off by default)")
    ap.add_argument("--max-leavers", type=int, default=10, help="abort if more leaver actions than this in one run (bad-feed guard)")
    ap.add_argument("--force", action="store_true", help="override --max-leavers guard")
    ap.add_argument("--active-on-create", action="store_true",
                    help="LAB ONLY: create users ACTIVE with a random unknown password so suspend can be demonstrated")
    ap.add_argument("--audit-log", default="jml_audit.jsonl")
    ap.add_argument("--mock", action="store_true", help="run against a local JSON tenant instead of Okta")
    ap.add_argument("--mock-state", default="mock_okta_state.json")
    ap.add_argument("--as-of", help="YYYY-MM-DD simulated 'today' (mock mode only)")
    a = ap.parse_args()

    now = datetime.now(timezone.utc)
    if a.as_of:
        if not a.mock:
            sys.exit("--as-of is only valid with --mock (live Okta uses real timestamps)")
        now = datetime.fromisoformat(a.as_of).replace(tzinfo=timezone.utc, hour=12)

    if a.mock:
        client = MockOkta(a.mock_state, now)
    else:
        org, tok = os.environ.get("OKTA_ORG_URL"), os.environ.get("OKTA_API_TOKEN")
        if not org or not tok:
            sys.exit("Set OKTA_ORG_URL and OKTA_API_TOKEN (or use --mock)")
        client = OktaClient(org, tok)

    rows = load_feed(a.csv)
    plan = build_plan(rows, client, a, now)

    leaver_ops = sum(1 for p in plan if p["action"].startswith("LEAVER_"))
    if leaver_ops > a.max_leavers and not a.force:
        sys.exit(f"ABORT: {leaver_ops} leaver actions exceeds --max-leavers {a.max_leavers}. "
                 "Check the feed, or re-run with --force.")

    errors = execute(plan, a, now)
    counts: dict[str, int] = {}
    for p in plan:
        counts[p["action"]] = counts.get(p["action"], 0) + 1
    print(f"\nfeed rows: {len(rows)} | planned: {counts or 'nothing to do'} | errors: {errors}")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
